import {DB} from './models';

export const db = new DB();
