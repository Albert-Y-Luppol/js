export interface Timer {
  hours: number;
  minutes: number;
  seconds: number;
}
